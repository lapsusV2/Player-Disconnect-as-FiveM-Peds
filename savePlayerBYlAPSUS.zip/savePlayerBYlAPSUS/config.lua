Config = {}
Config.FreezePeds = true  -- Définir sur true si vous souhaitez que le ped soit freeze et invincible
Config.systemVetement = 'fivem-appearance' -- ou 'illenium-appearance'