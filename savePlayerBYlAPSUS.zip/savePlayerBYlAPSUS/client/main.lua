local sleepingPeds = {}
--local Config = require("config")  -- Assurez-vous que le chemin est correct pour votre configuration

RegisterNetEvent('L_savePlayer:createSleepingPed')
AddEventHandler('L_savePlayer:createSleepingPed', function(coords, appearance, identifier)
    -- Vérifier si un ped existe déjà pour cet identifiant
    if sleepingPeds[identifier] and DoesEntityExist(sleepingPeds[identifier]) then
        print("Ped already exists for identifier:", identifier)
        return
    end

    local model = GetHashKey(appearance.model)

    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(1)
    end

    local ped = CreatePed(4, model, coords.x, coords.y, coords.z, 0.0, false, true)
    SetEntityAsMissionEntity(ped, true, true)

    -- Appliquer l'apparence
    exports[Config.systemVetement]:setPedAppearance(ped, appearance)

    -- Assurez-vous que le ped est créé avant de commencer l'animation
    Citizen.Wait(500)

    -- Charger le dictionnaire d'animation
    local animDict = "timetable@tracy@sleep@"
    local animName = "idle_c"

    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Wait(1)
    end

    -- Jouer l'animation de sommeil sur le ped
    TaskPlayAnim(ped, animDict, animName, 8.0, -8.0, -1, 1, 0, false, false, false)

    -- Gel du ped si la configuration l'exige
    if Config.FreezePeds then
        FreezeEntityPosition(ped, true)
        SetPedCanRagdoll(ped, false)
        SetEntityInvincible(ped, true)
        SetBlockingOfNonTemporaryEvents(ped, true)
    end

    -- Assurez-vous que le ped ne réagit pas aux stimuli
    SetPedCanBeTargetted(ped, false)  -- Empêche le ped d'être ciblé
    SetPedCanRagdoll(ped, false)      -- Empêche le ped de tomber en ragdoll
    SetPedCanRagdollFromPlayerImpact(ped, false)  -- Empêche le ped de tomber en ragdoll à cause des impacts de joueur
    SetPedCombatAttributes(ped, 46, true)  -- Empêche le ped de réagir aux attaques
    SetPedFleeAttributes(ped, 0, 0)  -- Empêche le ped de fuir en cas d'attaque
    SetPedSeeingRange(ped, 0.0)  -- Réduit la portée de vision à 0
    SetPedHearingRange(ped, 0.0)  -- Réduit la portée d'audition à 0
    SetPedAlertness(ped, 0)  -- Réduit l'alerte du ped à 0
    SetPedNeverLeavesGroup(ped, true)  -- Empêche le ped de quitter un groupe

    -- Autres attributs pour désactiver les réactions du ped
    SetPedCanPlayAmbientAnims(ped, false)  -- Empêche le ped de jouer des animations ambiantes
    SetPedCanPlayGestureAnims(ped, false)  -- Empêche le ped de jouer des animations de gestes
    SetPedCanBeDraggedOut(ped, false)  -- Empêche le ped d'être traîné hors de son emplacement
    SetPedCanBeKnockedOffVehicle(ped, false)  -- Empêche le ped d'être éjecté d'un véhicule

    sleepingPeds[identifier] = ped
end)

RegisterNetEvent('L_savePlayer:deletePed')
AddEventHandler('L_savePlayer:deletePed', function(identifier)
    if sleepingPeds[identifier] and DoesEntityExist(sleepingPeds[identifier]) then
        -- Défaire le gel du ped avant de le supprimer, si nécessaire
        if Config.FreezePeds then
            FreezeEntityPosition(sleepingPeds[identifier], false)
            SetPedCanRagdoll(sleepingPeds[identifier], true)
            SetEntityInvincible(sleepingPeds[identifier], false)
        end
        DeletePed(sleepingPeds[identifier])
        sleepingPeds[identifier] = nil
    end
end)

AddEventHandler('playerSpawned', function()
    TriggerServerEvent('L_savePlayer:removeSleepingPed')
end)
