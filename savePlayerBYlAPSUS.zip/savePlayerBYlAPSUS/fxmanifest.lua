fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'LAPSUSV2'
description 'Script qui sauvegarde la position des joueur pour faire apparaitre un ped qui fait dodo.'
version '1.0.0'

shared_script 'config.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    '@es_extended/locale.lua',
    'config.lua',
    'server/main.lua'
}

client_scripts {
    '@es_extended/locale.lua',
    'config.lua',
    'client/main.lua'
}

dependencies {
    'es_extended',
    'oxmysql'
}

escrow_ignore {
    'config.lua'
}